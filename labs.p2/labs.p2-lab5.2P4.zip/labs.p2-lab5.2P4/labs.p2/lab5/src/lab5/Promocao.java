package lab5;

public interface Promocao {

	String getPrecoComPromo();
	
	double aplicaPromo(double preco, double fator);
}
