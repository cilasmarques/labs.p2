package lab5;

public interface Produto {

	String getId();
}
