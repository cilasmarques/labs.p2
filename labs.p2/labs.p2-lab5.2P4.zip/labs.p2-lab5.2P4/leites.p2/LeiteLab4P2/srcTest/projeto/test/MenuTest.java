package projeto.test;

import static org.junit.Assert.*;

import org.junit.Before;


import org.junit.Test;

public class MenuTest {


	@Before
	public void setUp() {
	}

	
	@Test
	public void testMenu() {
	}

}
